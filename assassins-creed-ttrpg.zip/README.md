# Assassin's Creed TTRPG Module

This module adds custom Assassin's Creed-themed content to FoundryVTT.

## Installation
1. Download the module ZIP file.
2. Extract it into your FoundryVTT `Data/modules/` folder.
3. Enable it in the module settings of your game.
